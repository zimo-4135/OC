用openc core configurator挂载EFI分区，依次点开EFI➡️OC，将主题文件夹中的Resources替换EFI中的文件夹，用openc core configurator打开config.plist文件，按照下图编辑后保存重启

![1](Picture/1.png)
